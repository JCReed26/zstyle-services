"""Standardize backend data with object for agents to use"""

# we need to create types for each to determine how we will access each place appropriately 
# as a team this will need to be documentation

VACATION_DB_JSON = {
    "session_id": "",
    "user_id": "", 
    "budget_min": "0",
    "budget_max": "10000",
    "location_options": {
        "1": "texas",
        "2": "orlando",
    },
    "location": ("texas", "1000", "", "", ""),
}

"""
location_options is a dict of tuples where the location name is the key
to standardize the data structure it should be like this 
{ "location_title": (location_title, macro_estimated_cost_of_trip, ) }
"""

# data will be filled in with locations from websites meaning values should be immutable
# ^ this is why we are using tuples 
# _options dicts are { "location_title": (location_title, cost, etc.) }

class Vacation():
    def __init__(self) -> None:
        self.location = ()
        self.location_options = dict()
        self.flight = ()
        self.flight_options = dict()
        self.hotel = ()
        self.hotel_options = dict()
        self.excursions = [] # flexible set of options to create a final vacation plan

    def get_location(self) -> tuple:
        return self.location

    def get_location_options(self) -> dict:
        return self.location_options
    
    def add_location_option(self, loc: dict) -> None:
        # type of loc is dic {"location_title": (data1, data2, data3)}
        pass

    def remove_location_option(self, location_title) -> None:
        pass 

    