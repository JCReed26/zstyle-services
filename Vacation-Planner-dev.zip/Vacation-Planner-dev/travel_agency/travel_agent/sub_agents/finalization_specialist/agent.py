from google.adk.agents import Agent 
from ....MODELS import FLASH_GEMINI

finalization_specialist = Agent(
    name="finalization_specialist"
    model=FLASH_GEMINI
    description="a special agent that takes multiple pieces of a vacation and organizes it into 1 completed vacation"
    instruction="a special agent that takes multiple pieces of a vacation and organizes it into 1 completed vacation"
)