# Sub Agents

The Sub Agents are ADK Agents that have the ability to take control of the chat
Each Agent will always do what they need to find result and give back control to travel_agent

> In order of folder list view in my personal vs code

## Excursion_Specialist

## Finalization_Specialist

## Flight_Specialist

## Hotel_Specialist 

## Location_Specialist