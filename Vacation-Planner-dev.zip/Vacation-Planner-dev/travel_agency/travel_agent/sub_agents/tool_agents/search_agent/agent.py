from google.adk.tools import google_search_tool
from google.adk.agents import Agent
from .prompt import SEARCH_AGENT_INS

search_agent = Agent(
    name="search_agent",
    description="A web search agent that can perform Google searches to find information on the internet.",
    instruction=SEARCH_AGENT_INS,
    tools=[google_search_tool],
    model="gemini-2.0-flash"
)