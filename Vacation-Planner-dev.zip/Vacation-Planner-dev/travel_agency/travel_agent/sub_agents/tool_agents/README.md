# Tool Agents

The Tools Agents are ADK Agents that DO NOT have the ability to take control of the chat
They can only return their requested information 
These are to help search through different sites, apis, mcp for data to sell to user
Used with AgentTool() wrap

> In order of folder list view in my personal vs code

## Airbnb_Agent


## Search_Agent
overall research agent 