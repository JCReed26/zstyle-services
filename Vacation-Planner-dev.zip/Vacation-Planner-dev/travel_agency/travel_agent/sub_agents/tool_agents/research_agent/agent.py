from typing import List

from pydantic import BaseModel, Field
from perplexity import Perplexity

client = Perplexity() # search returns a title and a url of which we will have to XYZ(CHECK GOOGLE BUILT IN TOOLS)

# Tools
def get_perplexity_sources(queries: list) -> dict:
    """Gets Good Reliable Sources For Agent To Google Search"""
    search = client.search.create(
        query=queries,
        max_results=5
    )

    # DEBUG 
    for result in search.results:
        print(f"{result.title}: {result.url}")

    return result

def prepare_response():
    """Take original information plus perplexity research and return to usual"""
    pass


# OUTPUT SCHEMA for Agent Tool - response only
class OutputSchema(BaseModel):
    query: str = Field(
        description="The original research query provided."
    )
    summary: str = Field(
        description="A consice summary of the key findings from the research"
    )
    detailed_report: str = Field(
        description="The full compiled report, including insights from google searches of perplexity given sources "
    )
    sources: List[dict] = Field(
        default=[],
        description="List of sources from perplexity"
    )
    confidence: float = Field(
        default = 0.8,
        ge=0.0,
        le=1.0,
        description="A confidence score (0.0 to 1.0) indicating the reliability of the findings based on source quality and consistency"
    )
    additional_notes: str = Field(
        description="Any additional notes, caveats, or suggestions for further research"
    )

# Research Agent Section
from ..search_agent.agent import search_agent
from google.adk.agents import Agent
from google.adk.tools.agent_tool import AgentTool
from .prompt import SEARCH_AGENT_INS

research_agent = Agent(
    name="research_agent",
    description="A research agent that can perform Google searches to find information on the internet.",
    instruction=SEARCH_AGENT_INS,
    sub_agents=[],
    output=OutputSchema
    tools=[get_perplexity_sources, AgentTool(search_agent)],
    model="gemini-2.0-flash"
)

