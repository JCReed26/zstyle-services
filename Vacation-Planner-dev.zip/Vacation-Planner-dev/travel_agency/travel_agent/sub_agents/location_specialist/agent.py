from google.adk.agents import Agent
from google.adk.tools.agent_tools import AgentTool
from .prompt import LOCATION_SPECIALIST_INST
from ....MODELS import FLASH_GEMINI

from ..tool_agents.research_agent.agent import research_agent

location_specialist = Agent(
    name="location_specialist",
    description="A master of finding cool vacation destinations that fit within given conditions",
    instruction=LOCATION_SPECIALIST_INST,
    tools=[AgentTool(research_agent)],
    model=FLASH_GEMINI
)