# adk imports
from google.adk.agents.llm_agent import Agent
from google.adk.tools.agent_tool import AgentTool
from .prompt import ROOT_AGENT_INS

# sub_agents
from sub_agents.location_specialist.agent import location_specialist
# from sub_agents.flight_specialist.agent import flight_specialist
# from sub_agents.hotel_specialist.agent import hotel_specialist
# from sub_agents.exursion_specialist.agent import excursion_specialist
from sub_agents.finalization_specialist.agent import finalization_specialist

# sub_agent.tool_agents
from sub_agents.tool_agents.research_agent.agent import research_agent
# from sub_agents.tool_agents.airbnb_agent.agent import airbnb_agent # for basic checks n stuff not into the main look yet

root_agent = Agent(
    model='gemini-2.5-flash',
    name='travel_agent',
    description='A lead salesman and client concierge for a travel agency',
    instruction=ROOT_AGENT_INS,
    tools=[AgentTool(research_agent)],
)
