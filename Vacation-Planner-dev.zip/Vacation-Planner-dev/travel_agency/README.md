This repo is strictly being made without AI. And Docs.

# Travel Agency ADK Multi-Agent System

## Travel Agent

This folder holds the ADK Multi-Agent Server 

## (SOON_TO_COME) Payment Agent

This folder holds an A2A accessible agent that strictly handles payments 
Payments will be processed using AP2 

## MCP_API

This folder holds mcp servers that sub_agents will be able to connect to.

For now the plan is to run MCP_API servers 
    on port 5000 and go up by 10 
for each new integration.

## TODO

1. Check Imports across all files
2. document folder and file structure 
3. create process oriented sub_agents with toolagents as needed
    a. airbnb
    b. other location travel sites/apis etc 


## Agen(ts/cy)

Travel Agent - Orchestrator

    Sub Agents
        Excursion Specialist 
        Finalization Specialist 
        Flight Specialist
        Hotel Specialist
        Location Specialist 
    
    Tool Agents 
        airbnb agent
        research agent
        search agent 

## ideas (draft)
Orchestrator - This is the main travel agent it will communicate with the client and each of the 'sub-agents'

sub-agents
    planner - this agent is the main go-to that puts together all the information collected by orchestrator into a clean structured standardized data output
    flight-specialist - this agent knows about airplanes, airports, seat sizes, prices, best times to buy
    hotel-specialist - like the flight but for hotels 
    excursion-specialist - like the hotel but for excursions 
    booking-specialist - this agent does the physical reaching out and booking of the flight, hotel, and excursion; it can send emails, etc. it uses LLC AGENCY ACCOUNT for payments. it cannot schedule without confirmation that client paid. our profit margin then relies on booking before the price changes 

Tech-Stack 
    Google-ADK
    AI company APIs