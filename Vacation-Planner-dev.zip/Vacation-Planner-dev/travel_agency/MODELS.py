"""MODELS.py all models being used by the Travel Agency"""

FLASH_GEMINI = 'gemini-2.5-flash'
PRO_GEMINI = 'gemini-2.5-pro'

PERPLEXITY_RESEARCH = '' # for deep research reports on locations, hotels, everything 

GROK = ''   # most human imo for human interactable agents

GPT4O_MINI = '' # for simple easy tasks (find cheaper model)