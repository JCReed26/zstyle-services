# Copyright 2025 Google LLC
#
# Licensed under the Apache License, Version 2.0 (the "License");
# you may not use this file except in compliance with the License.
# You may obtain a copy of the License at
#
#     http://www.apache.org/licenses/LICENSE-2.0
#
# Unless required by applicable law or agreed to in writing, software
# distributed under the License is distributed on an "AS IS" BASIS,
# WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
# See the License for the specific language governing permissions and
# limitations under the License.

# TODO: Refactor Audio and Chat to Work like Grok Chat back n forth possible
# determine license usability issues too

import os
import asyncio
import base64
import json
from typing import AsyncIterable

import google.auth
from fastapi import FastAPI, WebSocket, Query
from google.adk.cli.fast_api import get_fast_api_app
from google.cloud import logging as google_cloud_logging
from opentelemetry import trace
from opentelemetry.sdk.trace import TracerProvider, export

# from app.utils.gcs import create_bucket_if_not_exists
# from app.utils.tracing import CloudTraceLoggingSpanExporter
# from app.utils.typing import Feedback
from travel_agent.agent import root_agent

# ADK live streaming imports
from google.adk.agents import LiveRequestQueue
from google.adk.agents.run_config import RunConfig
from google.adk.events.event import Event
from google.adk.runners import Runner
from google.adk.sessions.in_memory_session_service import InMemorySessionService
from google.genai import types

_, project_id = google.auth.default()
logging_client = google_cloud_logging.Client()
logger = logging_client.logger(__name__)
allow_origins = (
    os.getenv("ALLOW_ORIGINS", "").split(",") if os.getenv("ALLOW_ORIGINS") else None
)

bucket_name = f"gs://{project_id}-audio-test-logs-data"
create_bucket_if_not_exists(
    bucket_name=bucket_name, project=project_id, location="us-central1"
)

provider = TracerProvider()
processor = export.BatchSpanProcessor(CloudTraceLoggingSpanExporter())
provider.add_span_processor(processor)
trace.set_tracer_provider(provider)

AGENT_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# In-memory session configuration - no persistent storage
session_service_uri = None

app: FastAPI = get_fast_api_app(
    agents_dir=AGENT_DIR,
    web=True,
    artifact_service_uri=bucket_name,
    allow_origins=allow_origins,
    session_service_uri=session_service_uri,
)
app.title = "travel_agency"
app.description = "API for interacting with the Travel_Agency Agents"

@app.get("/health")
def healh_check():
    return {"status": "healthy"}

@app.post("/feedback")
def collect_feedback(feedback: Feedback) -> dict[str, str]:
    """Collect and log feedback.

    Args:
        feedback: The feedback data to log

    Returns:
        Success message
    """
    logger.log_struct(feedback.model_dump(), severity="INFO")
    return {"status": "success"}

# ---- A2A (For Future Implementation) ---

# ---- Server Routes (server -> agent) ---

# ---- WebSocket Live Streaming (text/audio) ----
APP_NAME = "travel_agency"
session_service = InMemorySessionService()


def start_agent_session(session_id: str, is_audio: bool = False):
    """Start an agent session and return live events + request queue."""

    # Create a Session (sync variant)
    session = session_service.create_session_sync(
        app_name=APP_NAME, user_id=session_id, session_id=session_id
    )

    # Create a Runner
    runner = Runner(app_name=APP_NAME, agent=root_agent, session_service=session_service)

    # Set response modality
    modality = "AUDIO" if is_audio else "TEXT"

    # Speech config (only used when audio is enabled)
    speech_config = types.SpeechConfig(
        voice_config=types.VoiceConfig(
            prebuilt_voice_config=types.PrebuiltVoiceConfig(voice_name="Puck")
        )
    )

    config: dict = {"response_modalities": [modality], "speech_config": speech_config}
    if is_audio:
        # Request both audio and text in responses
        config["output_audio_transcription"] = {}

    run_config = RunConfig(**config)

    # Create a LiveRequestQueue for this session
    live_request_queue = LiveRequestQueue()

    # Start agent session (async iterable of events)
    live_events = runner.run_live(
        session=session, live_request_queue=live_request_queue, run_config=run_config
    )
    return live_events, live_request_queue


async def agent_to_client_messaging(
    websocket: WebSocket, live_events: AsyncIterable[Event | None]
):
    """Forward agent events to client over WebSocket.

    Sends partial text chunks as JSON and audio as base64-encoded PCM.
    Also forwards turn_complete/interrupted flags.
    """
    while True:
        async for event in live_events:
            if event is None:
                continue

            if event.turn_complete or event.interrupted:
                message = {
                    "turn_complete": event.turn_complete,
                    "interrupted": event.interrupted,
                }
                await websocket.send_text(json.dumps(message))
                continue

            part = event.content and event.content.parts and event.content.parts[0]
            if not part or not isinstance(part, types.Part):
                continue

            # Stream partial text responses only (avoid duplicating final message)
            if getattr(part, "text", None) and getattr(event, "partial", False):
                message = {"mime_type": "text/plain", "data": part.text, "role": "model"}
                await websocket.send_text(json.dumps(message))
                continue

            # Send audio frames if present (audio/pcm)
            inline = getattr(part, "inline_data", None)
            if inline and getattr(inline, "mime_type", "").startswith("audio/pcm"):
                audio_data = getattr(inline, "data", None)
                if audio_data:
                    message = {
                        "mime_type": "audio/pcm",
                        "data": base64.b64encode(audio_data).decode("ascii"),
                        "role": "model",
                    }
                    await websocket.send_text(json.dumps(message))


async def client_to_agent_messaging(
    websocket: WebSocket, live_request_queue: LiveRequestQueue
):
    """Forward client messages to agent via LiveRequestQueue.

    Expects JSON messages like:
      { "mime_type": "text/plain", "data": "...", "role": "user" }
      { "mime_type": "audio/pcm",  "data": "<base64>" }
    """
    while True:
        message_json = await websocket.receive_text()
        message = json.loads(message_json)
        mime_type = message.get("mime_type")
        data = message.get("data")
        role = message.get("role", "user")

        if mime_type == "text/plain":
            content = types.Content(role=role, parts=[types.Part.from_text(text=data)])
            live_request_queue.send_content(content=content)
        elif mime_type == "audio/pcm":
            decoded = base64.b64decode(data)
            live_request_queue.send_realtime(types.Blob(data=decoded, mime_type=mime_type))
        else:
            raise ValueError(f"Mime type not supported: {mime_type}")


@app.websocket("/ws/{session_id}")
async def websocket_endpoint(
    websocket: WebSocket, session_id: str, is_audio: str = Query(...)
):
    """Client WebSocket endpoint compatible with Google sample protocol."""
    await websocket.accept()

    live_events, live_request_queue = start_agent_session(
        session_id=session_id, is_audio=(is_audio == "true")
    )

    agent_to_client_task = asyncio.create_task(
        agent_to_client_messaging(websocket, live_events)
    )
    client_to_agent_task = asyncio.create_task(
        client_to_agent_messaging(websocket, live_request_queue)
    )
    await asyncio.gather(agent_to_client_task, client_to_agent_task)


# Main execution
if __name__ == "__main__":
    import uvicorn

    uvicorn.run(app, host="0.0.0.0", port=4000)
