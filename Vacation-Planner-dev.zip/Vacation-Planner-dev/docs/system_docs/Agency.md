# Travel Agency 

The travel agency is a group of Agentic AI Agents built with ADK

It represents a the funtionality of a travel agent broken down into multiple research sections and workflows that allow the orchestrator travel agent to research organize and plan a full vacation plan itenerary

The itenerary goes across 3 main sections 
Locations       (location)
Flights         (transportation)
Hotels          (shelter)
Excursions      (events)
Misc            (misc)

