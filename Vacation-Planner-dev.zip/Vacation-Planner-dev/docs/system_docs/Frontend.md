# Frontend

The frontend is built using Next.js (React), TailwindCSS, and Zustand. It also uses component libraries, such as shadcn and daisy ui

Pages to be implemented include:

- Home page
- Login page
- Sign in page
- Forgot password page
- Profile page
- Profile edit page
- Settings page
- Plan page (which includes AI chatbox, chosen hotels, flight, and excursions, and preferences)
- Checkout page

Some of the components that might be used include:

- Navbar 
- Footer
- Login form
- Sign in form
- Text input (shadcn)
- Card (shadcn)
- Carousel (shadcn)
- Avatar (shadcn)
- Table (shadcn)
- Spinner (shadcn)
- Slider (shadcn)
- Dialog (shadcn)
- Resizable (shadcn)
- Sidebar (shadcn)
- Calendar (shadcn)
- Rating (daisy ui)
- Chat bubble (daisy ui)
- Drawer (shadcn)
- Separator (shadcn)
- Select (shadcn)
- Pagination (shadcn)
- Badge (shadcn)
- Separator (shadcn)