# Sprints 

To store iteractive section of sprints 
Sprints are setup as such 

- a group of tasks to implement that cannot be implemented until the completion of the previous sprint
- each sprint will be added to a kanban board pull style 
- after all of a sprints tasks are completed the next sprints tasks are added into the github

## Sprint 1 - post increment 1 


## The rest i need to break into splits

Frontend:
    - create profile output of user data
    - chat page functionality 1 - when first message sent remove templates on page and go into chat mode
    - chat functionality 2 
        - the orchestration agent will have an explicit statement hardcoded (ex. "ready to plan")
        - when this code kit hits the chat a special button in the chat will show with ^ string 
        - when the user hits this the chat page changes into the fully interactive full screen like chat page 
        - from here the user can save and exit / open and edit chat sessions 
        - these chat sessions will be viewable on _______________
Backend: 
    - create user routes for client information 
    - create auth routes for client login and token management 
    - design infra
        - ngnix load balancer and router (wss_routes to agent service, api_routes to backend, page_routes to frontend)
        - private internal VPC communication between agent service and backend 
Agents: 
    - 
    - create pre callback to get user information from database to agent 
        - if no user return error no collection allowed
    - create callback to get data from pre-plan into full plan 
    - optimize prompts