# Vacation-Planner
Full travel agency

## Quickstart
> docker-compose up --build
frontend port 2000
travel_agency port 4000
mcp/api_servers port 6000 - (for now inside travel_agency)
backend port 8000

recommended to use:
> docker-compose down && docker-compose up --build

To run application:
> docker-compose up -- build

clean before reuse:
> docker-compose down

list containers:
> docker-compose ps

## Tech-Stack
frontend - react 
backend - fastapi or flask?
database - postgres or something smaller 
agents - google ADK

## Breakdown
Plans out entire vacation

Talk to agent figure out 
    where you want to go 
    what you want to do
    where you would prefer to stay

Agents go through each area 
    flights 
    hotels 
    excursions 
    etc. 

Book
the agent goes and books under the travel agency on behalf of client 
the software brings all the data into one place and tracks for the user 

user should be able to have trips that take multiple flights hotels etc etc etc.

## UI Pages
Home-Profile - show profile data and past/current chats and show currently sheduled trips if any(visual box if none)
Start-Chat - left side parameters and middle chat to get inital information from the user for what they want/what they are looking for (this allows for window shoppers actual planners go to 'Chat-Plan')
Chat-Plan - left side parameters, right side chat, middle dropdowns for scheduling and viewing each piece of a trip (flights, hotels, excursions, etc)

## Database Tables/Structures
Tech-Stack
    postgres? - prolly cuz json store and keys - we dont need that big so a smaller database could work too

User Data
{ 
    "userid": "1",
    "username": "abcdef",
    "password": "abcedef",
    "email": "abdef@email.com",
    "phone": "000-000-0000",
    "jwt-key": "akdhfkjasdhn",
    "home-country": "United States",
    "home-state": "Florida",
    "home-city": "Tallahassee",
    "currency": "USD",
    "language": "English-US",
    "timezone": "EST",
    "past-chats": ['chats that havent become plans'],
    "past-plans": ['chats that hit the plan stage'],
    "scheduled-plans": ['chats that are scheduled and planned'],
    "past-trips": ['trips user already took']
}

Base Chats
{
    "chatid": "1",
    "userid": "1",
    "chat-log": [], 
    "parameters": []
}

Plan Chats (from base chat table, remove from base chat table when appending to plan chats)
{
    "planid": "1",
    "oldchatid": "1",
    "userid": "1",
    "plan-destination": "", 
    "plan-hotel": "",
    "plan-flight": "",
    "plan-excursion": "",
    "chat-log": [],
    "parameters": ['to track the set limitations']
}

Scheduled Chats (from plan chats when moved from planning stage to booking)
{
    "tripid": "1",
    "oldplanid": "1",
    "oldchatid": "1",
    "userid": "1",
    "trip-destination": "",
    "trip-hotel": "",
    "trip-flight": "",
    "trip-excursion": "",
    "special-data": ['for times on cron jobs, ticket company etc etc']
}

chat log 
{
   "from-user": [
    "time": "payload"
   ],
   "from-agent": [
    "time": "payload"
   ]
}

parameters
{
    "hotel": [
        "min": "x"
        "max": "x"
    ],
    "flight": [
        "min": "x"
        "max": "x"
    ],
    "excursion": [
        "min": "x"
        "max": "x"
    ]
}

special-data
{
    "flight": [
        data about flight(s)
    ],
    "hotel": [
        data about hotel(s)
    ],
    "excursion": [
        data about excursion(s)
    ]
}

## Agen(ts/cy)

Orchestrator - This is the main travel agent it will communicate with the client and each of the 'sub-agents'

sub-agents
    planner - this agent is the main go-to that puts together all the information collected by orchestrator into a clean structured standardized data output
    flight-specialist - this agent knows about airplanes, airports, seat sizes, prices, best times to buy
    hotel-specialist - like the flight but for hotels 
    excursion-specialist - like the hotel but for excursions 
    booking-specialist - this agent does the physical reaching out and booking of the flight, hotel, and excursion; it can send emails, etc. it uses LLC AGENCY ACCOUNT for payments. it cannot schedule without confirmation that client paid. our profit margin then relies on booking before the price changes 

Tech-Stack 
    Google-ADK
    AI company APIs

## Payments 

we want simple easy payments so integrations with pay over time clients etc etc etc.

Tech-Stack
    Stripe? Klarna? Custom?

## Infrastructure 

prolly docker and kubernetes through terraform IaC