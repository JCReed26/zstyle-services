"use client";

import React from "react";
import ProfileInfo from "../../components/ProfileInfo";
import PastChats from "../../components/PastChats";

const Page = () => {
  return (
    <div className="max-w-2xl mx-auto mt-20 p-4 space-y-4">
      <ProfileInfo />
      <PastChats />
    </div>
  );
};

export default Page;
