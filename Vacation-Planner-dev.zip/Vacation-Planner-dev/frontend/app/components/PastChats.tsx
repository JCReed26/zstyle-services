"use client";

import React from "react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";

const PastChats = () => {
  const chats = [
    {
      title: "Trip to Amsterdam",
      date: "Sep 20, 2025",
      status: "In Progress",
    },
    {
      title: "Trip to California",
      date: "May 6, 2025",
      status: "Completed",
    },
    {
      title: "Trip to Italy",
      date: "Dec 2, 2024",
      status: "Completed",
    },
  ];

  return (
    <div className="max-w-3xl mx-auto p-6">
      <h2 className="text-xl font-semibold mb-4">Past Chats</h2>

      <div className="rounded-md border border-border shadow-sm overflow-hidden">
        <Table>
          <TableHeader>
            <TableRow className="border-b border-border">
              <TableHead className="w-[50%]">Title</TableHead>
              <TableHead>Date</TableHead>
              <TableHead>Status</TableHead>
            </TableRow>
          </TableHeader>
          <TableBody className="divide-y divide-border">
            {chats.map((chat, i) => (
              <TableRow
                key={i}
                className="cursor-pointer hover:bg-muted/40 transition-colors"
              >
                <TableCell className="font-medium max-w-[250px] truncate whitespace-nowrap overflow-hidden">
                  {chat.title}
                </TableCell>
                <TableCell>{chat.date}</TableCell>
                <TableCell>{chat.status}</TableCell>
              </TableRow>
            ))}
          </TableBody>
        </Table>
      </div>
    </div>
  );
};

export default PastChats;
