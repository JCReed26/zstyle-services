"use client";

import React from "react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Pencil } from "lucide-react";

const ProfileInfo = () => {
  return (
    <div className="max-w-2xl mx-auto p-6">
      <div className="flex justify-center">
        <div className="flex items-center gap-8">
          <Avatar className="w-32 h-32">
            <AvatarImage/>
            <AvatarFallback></AvatarFallback>
          </Avatar>
          <div className="flex flex-col justify-center">
            <h1 className="text-4xl font-bold text-foreground pb-3">Test User</h1>
            <div className="flex items-center gap-2 mt-1 cursor-pointer text-muted-foreground hover:text-foreground/70 transition-colors w-fit pl-1">
              <Pencil className="w-4 h-4" />
              <span>Edit Profile</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProfileInfo;
