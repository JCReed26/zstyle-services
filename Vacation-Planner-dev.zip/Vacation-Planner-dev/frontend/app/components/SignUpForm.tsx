import React from 'react'
import { Button } from "@/components/ui/button"
import {
  Card,
  CardAction,
  CardContent,
  CardDescription,
  CardFooter,
  CardHeader,
  CardTitle,
} from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import Link from "next/link";
import countries from "@/app/data/countries.json";
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectLabel,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"

const LogOutForm = () => {
  return (
    <Card className="w-full max-w-sm border-border bg-background shadow-md flex flex-col">
      <CardHeader className="w-full text-center">
        <CardTitle>Create a new account</CardTitle>
        <CardDescription className="text-center pt-2">
          Enter your details to sign up for a new account
        </CardDescription>
      </CardHeader>
      <CardContent>
        <form>
          <div className="flex flex-col gap-6">
            <div className="grid gap-2">
              <Label htmlFor="name">Name</Label>
              <Input id="name" type="text" required/>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="lastName">Last Name</Label>
              <Input id="lastName" type="text" required/>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="email">Email</Label>
              <Input id="email" type="email" required/>
            </div>
            <div className="grid gap-2">
              <Label htmlFor="password">Password</Label>
              <Input id="password" type="password" required />
            </div>
            <div className="grid gap-2">
              <Label htmlFor="password">Confirm Password</Label>
              <Input id="password" type="password" required />
            </div>
          </div>
        </form>
      </CardContent>
      <CardFooter className="flex-col gap-2">
        <Button type="submit" className="w-full">
          Sign Up
        </Button>
        <CardDescription className="flex justify-center gap-1 pt-3">
          <span>Already have an account?</span>
          <Link
            href="/login"
            className="font-semibold text-muted-background hover:text-foreground/80 transition-colors duration-200"
          >
            Log in
          </Link>
      </CardDescription>
      </CardFooter>
    </Card>
  )
}

export default LogOutForm
