"use client";

import { useState, useEffect } from "react";
import Image from "next/image";
import Link from "next/link";
import {
  Avatar,
  AvatarFallback,
  AvatarImage,
} from "@/components/ui/avatar";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Button } from "@/components/ui/button";
import { Menu, X } from "lucide-react";

const Navbar = () => {
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50);
    };
    window.addEventListener("scroll", handleScroll);
    return () => window.removeEventListener("scroll", handleScroll);
  }, []);

  return (
    <nav
      className={`fixed top-0 left-0 right-0 z-50 transition-all duration-300 ${
        isScrolled
          ? "bg-background/80 backdrop-blur-md border-b border-border"
          : "bg-background border-b border-border"
      }`}
    >
      <div className="max-w-8xl mx-auto px-12 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2 text-xl font-semibold text-foreground cursor-pointer">
            <Image
              src="/assets/maprose.svg"
              alt="Logo"
              width={26}
              height={26}
            />
            <Link href="/">Vacation Planner</Link>
          </div>

          <div className="hidden md:flex items-center gap-6">
            {/* <a
              className="text-black font-semibold cursor-pointer hover:text-muted-foreground duration-300 transition-all transform hover:scale-105"
            >
              Log In
            </a> */}
            <Button className="border-border bg-secondary text-foreground hover:bg-secondary/60 transition-colors">
              <Link href="/">Home</Link>
            </Button>
            <Button className="border-border bg-secondary text-foreground hover:bg-secondary/60 transition-colors">
              <Link href="/plan">Plan</Link>
            </Button>
            <Button>
              <Link href="/login">Log In</Link>
            </Button>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Avatar className="cursor-pointer">
                  <AvatarFallback></AvatarFallback>
                </Avatar>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-40 border-border bg-background shadow-md">
                <DropdownMenuLabel>My Account</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem>
                  <Link href="/profile">Profile</Link>
                </DropdownMenuItem>
                <DropdownMenuItem>Settings</DropdownMenuItem>
                <DropdownMenuItem className="text-red-500">Log out</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          </div>

          <div className="md:hidden flex items-center space-x-4">
            <button
              className="text-foreground"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}>
              {isMobileMenuOpen ? (<X className="w-6 h-6" />) 
              : (<Menu className="w-6 h-6" />)}
            </button>
          </div>
        </div>

        {isMobileMenuOpen && (
          <div className="md:hidden mt-4 py-4 border-t border-border">
            <div className="flex flex-col space-y-4">
              <Link
                href="/"
                className="text-muted-foreground hover:text-foreground transition-colors duration-300 font-medium"
                onClick={() => setIsMobileMenuOpen(false)}>
                  Home
              </Link>
              <Link
                href="/plan"
                className="text-muted-foreground hover:text-foreground transition-colors duration-300 font-medium"
                onClick={() => setIsMobileMenuOpen(false)}>
                Plan
              </Link>
              <Link
                href="/login"
                className="text-muted-foreground hover:text-foreground transition-colors duration-300 font-medium"
                onClick={() => setIsMobileMenuOpen(false)}>
                Log In
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
};

export default Navbar;
