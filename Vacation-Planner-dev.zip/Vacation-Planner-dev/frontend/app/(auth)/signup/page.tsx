import React from 'react'
import LogoutForm from '../../components/SignUpForm'

const page = () => {
  return (
    // <div className="min-h-screen flex flex-col items-center justify-center bg-background py-12 pt-22">
    <div className="min-h-screen flex flex-col items-center justify-center bg-background">
      <LogoutForm />
    </div>
  )
}

export default page
