"use client"

import Image from "next/image"
import { Card, CardContent } from "@/components/ui/card"
import {
  Carousel,
  CarouselContent,
  CarouselItem,
  CarouselNext,
  CarouselPrevious,
} from "@/components/ui/carousel"
import Autoplay from "embla-carousel-autoplay"
import { useRef } from "react"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { ArrowRight } from "lucide-react";

export default function Home() {
  const plugin = useRef(
    Autoplay({ delay: 6000, stopOnInteraction: true })
  )

  return (
    <div className="px-8 relative min-h-screen flex flex-col items-center pt-30">
      <div className="relative z-10 text-center mb-4">
        <div className="flex items-center justify-center gap-4 mb-4">
          <Image 
            src="/assets/maprose.svg"
            alt="Logo" 
            width={64} 
            height={64} 
            className="w-12 h-12 sm:w-16 sm:h-16 md:w-20 md:h-20"
          />
          <h1 className="text-3xl md:text-6xl font-bold leading-tight">
            Vacation Planner
          </h1>
        </div>
        <div className="w-[70vw] mx-auto">
          <h2 className="text-md sm:text-md text-muted-foreground font-medium mb-6 text-center">
            Recently Planned Trips:
          </h2>
          <Carousel opts={{ align: "start", loop: true, skipSnaps: false }} plugins={[plugin.current]} className="w-full">
            <CarouselContent>
              {Array.from({ length: 8 }).map((_, index) => (
                <CarouselItem key={index} className="md:basis-1/2 lg:basis-1/5">
                  <div className="p-1">
                    <Card className="border-border">
                      <CardContent className="flex aspect-square items-center justify-center p-6">
                        <span className="text-3xl font-semibold">{index + 1}</span>
                      </CardContent>
                    </Card>
                  </div>
                </CarouselItem>
              ))}
            </CarouselContent>
            <CarouselPrevious className="border-border"/>
            <CarouselNext className="border-border"/>
          </Carousel>
        </div>
        
        <div className="flex justify-center mt-12 w-full">
          <div className="relative w-full max-w-2xl">
            <Input
              placeholder="Start planning..."
              className="rounded-full pr-14 h-12 pl-6" />
            <Button 
            className="absolute right-2 top-1/2 -translate-y-1/2 rounded-full w-8 h-8 flex items-center justify-center"
            >
              <ArrowRight className="w-5 h-5" />
            </Button>
          </div>
        </div>

      </div>
    </div>
  );
}
