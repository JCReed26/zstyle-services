 
# Backend for vacation planner

FastAPI backend, connects to Supabase for authentication and database

## Overview
    - FastAPI for the backend
    - Supabase for database and auth



## Setup
1. Clone the repo and navigate to backend
```bash
cd backend
```

2. Create a virtual environment
```bash
python -m venv venv
source venv/bin/activate
.\venv\Scripts\activate
```

3. Install dependencies
```bash
pip install -r requirements.txt
```

5. Copy .env.example to .env and add Supabase credentials
```bash
cp .env.example .env
```

7. Running the server
```bash
uvicorn main:app --reload
```



Current Available Routes:

GET / -> root message
GET /health -> Health check func
POST /auth/signup -> Create a new user
POST /auth/login -> Log in and return token
GET /users -> Get users from SupaBase
