from contextlib import asynccontextmanager
from fastapi import FastAPI, HTTPException
from dotenv import load_dotenv
from pydantic import BaseModel
from supabase_client.supabase import get_supabase_client

load_dotenv()

@asynccontextmanager
async def lifespan(app: FastAPI):
    supabase = get_supabase_client()
    if not supabase:
        raise ConnectionError("Could not connect to supabase")
    yield

app = FastAPI(lifespan=lifespan)

@app.get("/")
def read_root():
    return {"message": "Vacation Planner Backend is running"}


@app.get("/health")
def health_check():
    return {"status": "ok"}

class UserSignup(BaseModel):
    email: str
    password: str

@app.post("/auth/signup")
def signup(user: UserSignup):
    supabase = get_supabase_client()
    response = supabase.auth.sign_up({"email": user.email, "password": user.password})
    if not response.user:
        raise HTTPException(status_code=400, detail="Signup failed")
    return {"message": "User created", "user": response.user.email}

class UserLogin(BaseModel):
    email: str
    password: str

@app.post("/auth/login")
def login(user: UserLogin):
    supabase = get_supabase_client()
    response = supabase.auth.sign_in_with_password({"email": user.email, "password": user.password})
        if not response.session:
            raise HTTPException(status_code=401, detail="Invalid credentials")
        return {"access_token": response.session.access_token}

@app.get("/users")
def get_users():
    supabase = get_supabase_client()
    response = supabase.table("users").select("*").execute()
    return response.data
